from mathinspector.app import main
main()
