from .app import main


if __name__ == '__main__':
	# mp.freeze_support() #required for windows
	main()
